#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#pragma warning(disable:4996)
int main(void) {
	//���� �Է����� ����
	freopen("sample_input.txt", "r", stdin);
	//
	char* ptr = (char*)malloc(sizeof(char) * 256);
	double** arr = (double**)malloc(sizeof(char) * 2000);
	int arr_row_index = 0;
	while (1) {
		double sum = 0;
		if (scanf("%s", ptr) == -1)
			break;
		arr[arr_row_index] = (double*)malloc(sizeof(double) * 4);
		scanf("%s", ptr);
		ptr = strtok(ptr, ":");
		printf("%s\n", ptr);
		arr[arr_row_index][0] = atof(ptr);//��

		ptr = strtok(NULL, ":");
		printf("%s\n", ptr);
		arr[arr_row_index][1] = atof(ptr);//��

		ptr = strtok(NULL, "");
		printf("%s\n", ptr);
		arr[arr_row_index][2] = atof(ptr);//��

		scanf("%s", ptr);
		ptr = strtok(ptr, "s");
		printf("%s\n", ptr);
		arr[arr_row_index][3] = atof(ptr);//�����ð�
		arr_row_index++;
	}
	//���ӽð� ���
	int max = 1;
	for (int i = 0; i < arr_row_index; i++)
	{
		//���� sec
		double i_start = arr[i][0] * 60 * 60 + arr[i][1] * 60 + arr[i][2] - arr[i][3] + 0.001;
		double i_end = arr[i][0] * 60 * 60 + arr[i][1] * 60 + arr[i][2];
		int i_sum = 1;
		for (int j = 0; j < arr_row_index, j != i; j++) {
			//i�� ���۽ð����� j�� ���۽ð��� Ŭ ��� ��ģ�� 
			double j_start = arr[j][0] * 60 * 60 + arr[j][1] * 60 + arr[j][2] - arr[j][3] + 0.001;
			double j_end = arr[j][0] * 60 * 60 + arr[j][1] * 60 + arr[j][2];
			if (i_start - 0.999 <= j_end || i_end + 0.999 <= j_start) {
				i_sum++;
			}
		}
		if (max < i_sum) {
			max = i_sum;
		}
	}
	//���
	printf("MAX : %d\n", max);
	return 0;
}