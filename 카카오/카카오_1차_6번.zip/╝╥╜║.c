#include <stdio.h>
#include <malloc.h>
#pragma warning(disable:4996)
int main(void) {
	freopen("sample_input.txt", "r", stdin);
	int m;
	int n;
	scanf("%d", &n);
	scanf("%d", &m);
	char **arr;
	int **check;
	arr = (char**)malloc(sizeof(char*) * n);
	check = (char**)malloc(sizeof(int*) * n);
	for (int i = 0; i < n; i++) {
		arr[i] = (char*)malloc(sizeof(char) * m);
		check[i] = (char*)malloc(sizeof(int) * m);
	}
	for (int i = 0; i < n; i++) {
		scanf("%s", arr[i]);
	}
	while (1) {
		//�ʱ�ȭ
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				check[i][j] = 0;
			}
		}
		//Ž��
		for (int i = 0; i < n- 1; i++) {
			for (int j = 0; j < m - 1; j++) {
				if (arr[i][j] != ' ' &&
					arr[i][j] == arr[i][j + 1] &&
					arr[i][j + 1] == arr[i + 1][j] &&
					arr[i + 1][j] == arr[i + 1][j + 1]) {
					check[i][j] = 1;
					check[i][j + 1] = 1;
					check[i + 1][j] = 1;
					check[i + 1][j + 1] = 1;
				}
			}
		}
		//���� + �̵�
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (check[i][j] == 1) {
					for (int k = i - 1; k >= 0; k--) {
						arr[k + 1][j] = arr[k][j];
					}
					arr[0][j] = ' ';
				}
			}
		}
		//�˻�
		int sum = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				sum += check[i][j];
			}
		}
		if (sum == 0)
			break;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				printf("%c", arr[i][j]);
			}
			printf("\n");
		}
		printf("===========\n");
	}
	//���
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			printf("%c", arr[i][j]);
		}
		printf("\n");
	}
	return 0;
}